class AI {
    public: int getMove(int n, int cM, int cR, int oR, int eR);
};